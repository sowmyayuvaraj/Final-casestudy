package com.digitalbooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigitalBooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigitalBooksApplication.class, args);
	}

}
